﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PeterKottas.DotNetCore.WindowsService.Interfaces
{
    public interface IMicroServiceController
    {
        void Stop();
    }
}
